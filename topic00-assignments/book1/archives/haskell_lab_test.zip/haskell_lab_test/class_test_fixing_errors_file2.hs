-- For full instructions see the other file (class_test.hs)
-- PLEASE FILL THIS IN
-- Student Name : 



-- Fix the error in the file below. Load the file, read the error mesage
-- and fix ONE ERROR at a time. Then load the file and read the next error
-- message. 


a1:: Integer
a1 = True                   

a2 = seven * 6             

 a3 = 99                    
 
a4 = length 4.0             

a7 = if a3=99 then 1 else 0     



a9:: Int -> Int
a9 x = x `div` 2

a10 = a9 a5

a11 = 4 && True               